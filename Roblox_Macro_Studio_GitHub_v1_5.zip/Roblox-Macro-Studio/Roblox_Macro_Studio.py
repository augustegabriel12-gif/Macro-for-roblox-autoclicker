import json
import ctypes
import os
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pynput import keyboard, mouse
from pynput.keyboard import Key, Controller as KeyboardController
from pynput.mouse import Button, Controller as MouseController

APP_TITLE = "Roblox Macro Studio"
VERSION = "1.5"

class MacroStudio:
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_TITLE} {VERSION}")
        self.root.geometry("820x730")
        self.root.minsize(720, 620)
        self.language = "en"
        self.theme = "dark"
        self.root.configure(bg="#111827")

        self.events = []
        self.recording = False
        self.playing = False
        self.stop_event = threading.Event()
        self.spam_stop_event = threading.Event()
        self.spam_running = False
        self.record_start = 0.0
        self.last_event_time = 0.0
        self.keyboard_controller = KeyboardController()
        self.mouse_controller = MouseController()
        self.keyboard_listener = None
        self.mouse_listener = None
        self.hotkey_listener = None
        self._pressed = set()
        self._last_move_stamp = 0.0
        self._last_move_pos = None
        self._last_move_stamp = 0.0
        self._recorded_buttons = set()
        self._play_lock = threading.Lock()

        self.status = tk.StringVar(value="Prêt. F8 arrête la lecture et les répétitions.")
        self.repeat_var = tk.StringVar(value="1")
        self.speed_var = tk.StringVar(value="1.0")
        self.hotkey_record_var = tk.StringVar(value="F6")
        self.hotkey_delete_var = tk.StringVar(value="F7")
        self.click_interval_var = tk.StringVar(value="0.10")
        self.spam_key_var = tk.StringVar(value="e")
        self.spam_interval_var = tk.StringVar(value="0.10")
        self._build_ui()
        self._start_hotkey_listener()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#111827")
        style.configure("TLabel", background="#111827", foreground="#e5e7eb", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground="#93c5fd")
        style.configure("Sub.TLabel", foreground="#9ca3af")
        style.configure("TButton", font=("Segoe UI", 10), padding=7)
        style.configure("TLabelframe", background="#111827", foreground="#e5e7eb")
        style.configure("TLabelframe.Label", background="#111827", foreground="#93c5fd")

        outer = ttk.Frame(self.root, padding=16)
        outer.pack(fill="both", expand=True)
        title_row = ttk.Frame(outer)
        title_row.pack(fill="x")
        ttk.Label(title_row, text="Roblox Macro Studio", style="Title.TLabel").pack(side="left", anchor="w")
        ttk.Button(title_row, text="⚙ Settings", command=self.open_settings).pack(side="right")
        ttk.Label(outer, text="Touches, clics et points souris • F6 enregistrer • F7 effacer • F8 arrêt d'urgence", style="Sub.TLabel").pack(anchor="w", pady=(3, 5))
        ttk.Label(outer, text="La souris enregistre des points importants. Avec un bouton maintenu, elle suit le geste plus précisément.", style="Sub.TLabel").pack(anchor="w", pady=(0, 10))

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(0, 9))
        self.record_btn = ttk.Button(actions, text="● Enregistrer", command=self.toggle_recording)
        self.record_btn.pack(side="left", padx=(0, 7))
        self.stop_record_btn = ttk.Button(actions, text="■ Terminer", command=self.stop_recording, state="disabled")
        self.stop_record_btn.pack(side="left", padx=(0, 7))
        self.play_btn = ttk.Button(actions, text="▶ Lire la macro", command=self.play_macro)
        self.play_btn.pack(side="left", padx=(0, 7))
        ttk.Button(actions, text="⏹ Arrêter (F8)", command=self.stop_all).pack(side="left")

        settings = ttk.LabelFrame(outer, text="Lecture de macro", padding=9)
        settings.pack(fill="x", pady=(0, 9))
        ttk.Label(settings, text="Répétitions (0 = infinies) :").grid(row=0, column=0, sticky="w", padx=(0, 6), pady=3)
        ttk.Entry(settings, textvariable=self.repeat_var, width=8).grid(row=0, column=1, sticky="w", pady=3)
        ttk.Label(settings, text="Vitesse (1.0 = normale) :").grid(row=0, column=2, sticky="w", padx=(18, 6), pady=3)
        ttk.Entry(settings, textvariable=self.speed_var, width=8).grid(row=0, column=3, sticky="w", pady=3)

        tools = ttk.LabelFrame(outer, text="Auto-clicker et spam de touche", padding=9)
        tools.pack(fill="x", pady=(0, 9))
        ttk.Label(tools, text="Auto-clicker, intervalle en secondes :").grid(row=0, column=0, sticky="w", padx=(0, 6), pady=4)
        ttk.Entry(tools, textvariable=self.click_interval_var, width=9).grid(row=0, column=1, sticky="w", pady=4)
        ttk.Button(tools, text="Démarrer auto-clic", command=self.start_autoclick).grid(row=0, column=2, padx=6, pady=4)
        ttk.Label(tools, text="Touche à répéter :").grid(row=1, column=0, sticky="w", padx=(0, 6), pady=4)
        ttk.Entry(tools, textvariable=self.spam_key_var, width=12).grid(row=1, column=1, sticky="w", pady=4)
        ttk.Button(tools, text="Choisir une touche…", command=self.capture_spam_key).grid(row=1, column=2, sticky="w", padx=6, pady=4)
        ttk.Label(tools, text="Intervalle (secondes) :").grid(row=1, column=3, sticky="e", padx=6, pady=4)
        ttk.Entry(tools, textvariable=self.spam_interval_var, width=9).grid(row=1, column=4, sticky="w", pady=4)
        ttk.Button(tools, text="Démarrer spam de touche", command=self.start_key_spam).grid(row=2, column=0, columnspan=2, sticky="ew", padx=(0, 6), pady=4)
        ttk.Button(tools, text="Arrêter les répétitions", command=self.stop_spam_tools).grid(row=2, column=2, columnspan=3, sticky="ew", padx=6, pady=4)
        ttk.Label(tools, text="F8 arrête la lecture et les outils répétitifs. Espace et les touches spéciales sont acceptés.", style="Sub.TLabel").grid(row=3, column=0, columnspan=5, sticky="w", pady=(3, 0))

        hotkeys = ttk.LabelFrame(outer, text="Raccourcis personnalisables", padding=9)
        hotkeys.pack(fill="x", pady=(0, 9))
        ttk.Label(hotkeys, text="Enregistrer / terminer :").grid(row=0, column=0, sticky="w", padx=(0, 5), pady=3)
        ttk.Entry(hotkeys, textvariable=self.hotkey_record_var, width=7).grid(row=0, column=1, sticky="w", pady=3)
        ttk.Label(hotkeys, text="Effacer la macro :").grid(row=0, column=2, sticky="w", padx=(16, 5), pady=3)
        ttk.Entry(hotkeys, textvariable=self.hotkey_delete_var, width=7).grid(row=0, column=3, sticky="w", pady=3)
        ttk.Button(hotkeys, text="Appliquer", command=self.apply_hotkeys).grid(row=0, column=4, padx=(12, 0), pady=3)

        mid = ttk.Frame(outer)
        mid.pack(fill="both", expand=True)
        left = ttk.Frame(mid)
        left.pack(side="left", fill="both", expand=True)
        ttk.Label(left, text="Actions enregistrées").pack(anchor="w", pady=(0, 5))
        self.listbox = tk.Listbox(left, bg="#0b1220", fg="#e5e7eb", selectbackground="#2563eb",
                                  font=("Consolas", 9), relief="flat", activestyle="none", height=9)
        self.listbox.pack(fill="both", expand=True)
        scrollbar = ttk.Scrollbar(self.listbox, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        side = ttk.Frame(mid, padding=(10, 0, 0, 0))
        side.pack(side="right", fill="y")
        ttk.Button(side, text="Supprimer la sélection", command=self.delete_selected).pack(fill="x", pady=(22, 6))
        ttk.Button(side, text="Effacer toute la macro (F7)", command=self.clear_events).pack(fill="x", pady=6)
        ttk.Button(side, text="Enregistrer dans un fichier…", command=self.save_macro).pack(fill="x", pady=6)
        ttk.Button(side, text="Ouvrir une macro…", command=self.load_macro).pack(fill="x", pady=6)
        ttk.Label(side, text="Conseils", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(15, 4))
        ttk.Label(side, text="• Teste d'abord dans\n  une fenêtre sans risque.\n\n• F8 arrête les actions.\n\n• Les jeux peuvent\n  limiter les macros.", style="Sub.TLabel", justify="left").pack(anchor="w")

        ttk.Separator(outer).pack(fill="x", pady=(10, 7))
        ttk.Label(outer, textvariable=self.status).pack(anchor="w")
        self._apply_theme()
        self._apply_language()

    def open_settings(self):
        win = tk.Toplevel(self.root)
        win.title("Settings")
        win.transient(self.root)
        win.grab_set()
        win.resizable(False, False)
        frame = ttk.Frame(win, padding=16)
        frame.pack(fill="both", expand=True)
        lang_var = tk.StringVar(value=self.language)
        theme_var = tk.StringVar(value=self.theme)
        ttk.Label(frame, text="Language / Langue").grid(row=0, column=0, sticky="w", pady=6)
        ttk.Combobox(frame, textvariable=lang_var, values=("English", "Français"), state="readonly", width=18).grid(row=0, column=1, padx=(12, 0), pady=6)
        ttk.Label(frame, text="App style / Thème").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Combobox(frame, textvariable=theme_var, values=("Dark", "Light"), state="readonly", width=18).grid(row=1, column=1, padx=(12, 0), pady=6)
        def apply():
            self.language = "en" if lang_var.get() == "English" else "fr"
            self.theme = "dark" if theme_var.get() == "Dark" else "light"
            for child in list(self.root.winfo_children()):
                child.destroy()
            self._build_ui()
            win.destroy()
        ttk.Button(frame, text="Apply", command=apply).grid(row=2, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        win.update_idletasks()
        win.geometry(f"+{self.root.winfo_x()+80}+{self.root.winfo_y()+80}")

    def _apply_theme(self):
        style = ttk.Style()
        if self.theme == "light":
            bg, fg, sub, accent, list_bg = "#f3f4f6", "#111827", "#4b5563", "#1d4ed8", "#ffffff"
        else:
            bg, fg, sub, accent, list_bg = "#111827", "#e5e7eb", "#9ca3af", "#93c5fd", "#0b1220"
        self.root.configure(bg=bg)
        style.configure("TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg)
        style.configure("Title.TLabel", foreground=accent)
        style.configure("Sub.TLabel", background=bg, foreground=sub)
        style.configure("TLabelframe", background=bg, foreground=fg)
        style.configure("TLabelframe.Label", background=bg, foreground=accent)
        for widget in self.root.winfo_children():
            self._theme_widget(widget, bg, fg, list_bg)

    def _theme_widget(self, widget, bg, fg, list_bg):
        try:
            if isinstance(widget, tk.Listbox):
                widget.configure(bg=list_bg, fg=fg)
            elif isinstance(widget, tk.Toplevel):
                widget.configure(bg=bg)
            elif isinstance(widget, tk.Frame):
                widget.configure(bg=bg)
        except tk.TclError:
            pass
        for child in widget.winfo_children():
            self._theme_widget(child, bg, fg, list_bg)

    def _apply_language(self):
        if self.language != "en":
            return
        translations = {
            "Touches, clics et points souris • F6 enregistrer • F7 effacer • F8 arrêt d'urgence": "Keyboard, clicks and mouse points • F6 record • F7 clear • F8 emergency stop",
            "La souris enregistre des points importants. Avec un bouton maintenu, elle suit le geste plus précisément.": "Mouse movement is sampled at key points. Holding a button records the gesture more closely.",
            "● Enregistrer": "● Record", "■ Terminer": "■ Finish", "▶ Lire la macro": "▶ Play macro", "⏹ Arrêter (F8)": "⏹ Stop (F8)",
            "Lecture de macro": "Macro playback", "Répétitions (0 = infinies) :": "Repeats (0 = infinite):", "Vitesse (1.0 = normale) :": "Speed (1.0 = normal):",
            "Auto-clicker et spam de touche": "Auto-clicker and key spam", "Auto-clicker, intervalle en secondes :": "Auto-click interval (seconds):",
            "Démarrer auto-clic": "Start auto-clicker", "Touche à répéter :": "Key to repeat:", "Choisir une touche…": "Choose a key…",
            "Intervalle (secondes) :": "Interval (seconds):", "Démarrer spam de touche": "Start key spam", "Arrêter les répétitions": "Stop repetitions",
            "F8 arrête la lecture et les outils répétitifs. Espace et les touches spéciales sont acceptés.": "F8 stops playback and repeat tools. Space and special keys are supported.",
            "Raccourcis personnalisables": "Custom hotkeys", "Enregistrer / terminer :": "Record / finish:", "Effacer la macro :": "Clear macro:",
            "Appliquer": "Apply", "Actions enregistrées": "Recorded actions", "Supprimer la sélection": "Delete selected",
            "Effacer toute la macro (F7)": "Clear entire macro (F7)", "Enregistrer dans un fichier…": "Save to file…", "Ouvrir une macro…": "Open macro…",
            "Conseils": "Tips", "• Teste d'abord dans\n  une fenêtre sans risque.\n\n• F8 arrête les actions.\n\n• Les jeux peuvent\n  limiter les macros.": "• Test in a safe window first.\n\n• F8 stops actions.\n\n• Games may limit macros.",
            "⚙ Settings": "⚙ Settings",
        }
        def walk(widget):
            try:
                current = widget.cget("text")
                if current in translations:
                    widget.configure(text=translations[current])
            except (tk.TclError, TypeError):
                pass
            for child in widget.winfo_children():
                walk(child)
        for child in self.root.winfo_children():
            walk(child)

    def _key_name(self, key):
        if isinstance(key, Key):
            return key.name.upper() if key.name.startswith("f") else "Key." + key.name
        try:
            return key.char
        except AttributeError:
            return str(key)

    def _key_from_name(self, name):
        if name.startswith("Key."):
            return getattr(Key, name[4:], None)
        if name.upper().startswith("F") and name[1:].isdigit():
            return getattr(Key, name.lower(), name)
        return name

    def _start_hotkey_listener(self):
        def on_press(key):
            if key == Key.f8:
                self.root.after(0, self.stop_all)
                return
            name = self._key_name(key).upper()
            if name == self.hotkey_record_var.get().strip().upper():
                self.root.after(0, self.toggle_recording)
            elif name == self.hotkey_delete_var.get().strip().upper():
                self.root.after(0, self.clear_events)
        self.hotkey_listener = keyboard.Listener(on_press=on_press)
        self.hotkey_listener.daemon = True
        self.hotkey_listener.start()

    def apply_hotkeys(self):
        record_key = self.hotkey_record_var.get().strip().upper()
        delete_key = self.hotkey_delete_var.get().strip().upper()
        allowed = {f"F{i}" for i in range(1, 13)}
        if record_key not in allowed or delete_key not in allowed:
            messagebox.showerror(APP_TITLE, "Utilise des touches F1 à F12 pour ces raccourcis.")
            return
        if record_key == delete_key or "F8" in (record_key, delete_key):
            messagebox.showerror(APP_TITLE, "Choisis deux touches différentes. F8 est réservé à l'arrêt d'urgence.")
            return
        self.status.set(f"Raccourcis appliqués : {record_key} enregistrer, {delete_key} effacer, F8 arrêt.")

    def toggle_recording(self):
        if self.recording:
            self.stop_recording()
        else:
            self.start_recording()

    def _stamp(self, kind, data):
        now = time.perf_counter()
        delay = max(0.0, now - self.last_event_time) if self.events else 0.0
        self.last_event_time = now
        self.events.append({"kind": kind, "delay": delay, **data})
        # Tkinter doit être modifié depuis son thread principal, jamais depuis les listeners.
        try:
            self.root.after(0, self._refresh_list)
        except tk.TclError:
            pass

    def start_recording(self):
        if self.playing or self.spam_running:
            messagebox.showwarning(APP_TITLE, "Arrête d'abord la lecture ou les répétitions.")
            return
        self.events = []
        self._refresh_list()
        self.recording = True
        self.record_start = time.perf_counter()
        self.last_event_time = self.record_start
        self._pressed.clear()
        self._recorded_buttons.clear()
        # Snapshot the app window bounds so clicks on Record/Stop/Settings aren't added to the macro.
        try:
            self.root.update_idletasks()
            app_left, app_top = self.root.winfo_rootx(), self.root.winfo_rooty()
            app_right = app_left + self.root.winfo_width()
            app_bottom = app_top + self.root.winfo_height()
        except tk.TclError:
            app_left = app_top = app_right = app_bottom = -1

        def on_press(key):
            if not self.recording or key == Key.f8:
                return
            # The record hotkey itself is a control, not part of the user's intended macro.
            if self._key_name(key).upper() == self.hotkey_record_var.get().strip().upper():
                return
            name = self._key_name(key)
            if name not in self._pressed:
                self._pressed.add(name)
                self._stamp("key_down", {"key": name})

        def on_release(key):
            if not self.recording or key == Key.f8:
                return
            name = self._key_name(key)
            self._pressed.discard(name)
            self._stamp("key_up", {"key": name})

        def on_click(x, y, button, pressed):
            if not self.recording:
                return
            # Ignore clicks on the macro app itself, such as the button used to finish recording.
            if app_left <= x <= app_right and app_top <= y <= app_bottom:
                return
            name = button.name
            if pressed:
                self._recorded_buttons.add(name)
            else:
                self._recorded_buttons.discard(name)
            self._stamp("mouse_down" if pressed else "mouse_up", {
                "x": int(x), "y": int(y), "button": name
            })

        def on_move(x, y):
            if not self.recording:
                return
            now = time.perf_counter()
            pos = (int(x), int(y))
            if self._last_move_pos is None:
                self._last_move_pos = pos
                self._last_move_stamp = now
                # Le premier point est utile si la souris bouge pendant un clic maintenu.
                if self._recorded_buttons:
                    self._stamp("mouse_move_delta", {"dx": 0, "dy": 0, "x": pos[0], "y": pos[1]})
                return

            dx = pos[0] - self._last_move_pos[0]
            dy = pos[1] - self._last_move_pos[1]
            distance_sq = dx * dx + dy * dy
            held = bool(self._recorded_buttons)

            # Mouvement normal : seulement les points significatifs.
            # Bouton maintenu (ex. clic droit) : points plus rapprochés pour suivre le geste.
            min_distance_sq = 16 if held else 100
            min_interval = 0.035 if held else 0.075
            if distance_sq >= min_distance_sq and now - self._last_move_stamp >= min_interval:
                self._last_move_pos = pos
                self._last_move_stamp = now
                self._stamp("mouse_move_delta", {"dx": dx, "dy": dy, "x": pos[0], "y": pos[1]})

        self._last_move_pos = None
        self._last_move_stamp = 0.0
        self.keyboard_listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        self.mouse_listener = mouse.Listener(on_click=on_click, on_move=on_move)
        self.keyboard_listener.start()
        self.mouse_listener.start()
        self.record_btn.configure(state="disabled")
        self.stop_record_btn.configure(state="normal")
        self.play_btn.configure(state="disabled")
        self.status.set("🔴 Enregistrement en cours… utilise le bouton Terminer ou le raccourci choisi.")

    def stop_recording(self):
        if not self.recording:
            return
        self.recording = False
        self._recorded_buttons.clear()
        for listener in (self.keyboard_listener, self.mouse_listener):
            if listener:
                listener.stop()
        self.record_btn.configure(state="normal")
        self.stop_record_btn.configure(state="disabled")
        self.play_btn.configure(state="normal")
        self.status.set(f"Enregistrement terminé : {len(self.events)} actions.")
        self._refresh_list()

    def play_macro(self):
        if self.recording:
            messagebox.showwarning(APP_TITLE, "Termine l'enregistrement avant la lecture.")
            return
        if self.spam_running:
            messagebox.showwarning(APP_TITLE, "Arrête les répétitions avant de lire une macro.")
            return
        if not self.events:
            messagebox.showinfo(APP_TITLE, "Enregistre d'abord une macro ou ouvre un fichier.")
            return
        try:
            repeats = int(self.repeat_var.get())
            speed = float(self.speed_var.get())
            if repeats < 0 or speed <= 0 or speed > 20:
                raise ValueError
        except ValueError:
            messagebox.showerror(APP_TITLE, "Répétitions : entier positif ou 0. Vitesse : entre 0 et 20, sans 0.")
            return
        self.stop_event.clear()
        self.playing = True
        self.play_btn.configure(state="disabled")
        self.record_btn.configure(state="disabled")
        self.status.set("Lecture dans 3 secondes… sélectionne la fenêtre cible.")
        threading.Thread(target=self._play_worker, args=(repeats, speed), daemon=True).start()

    def _play_worker(self, repeats, speed):
        held_keys = set()
        held_buttons = set()
        try:
            # Laisse le temps de sélectionner Roblox, sans déplacer la souris pendant ce délai.
            time.sleep(3)
            loop = 0
            while not self.stop_event.is_set() and (repeats == 0 or loop < repeats):
                for event in list(self.events):
                    if self.stop_event.is_set():
                        break
                    time.sleep(min(event.get("delay", 0) / speed, 10))
                    if self.stop_event.is_set():
                        break
                    self._perform(event)
                    if event["kind"] == "key_down":
                        held_keys.add(event["key"])
                    elif event["kind"] == "key_up":
                        held_keys.discard(event["key"])
                    elif event["kind"] == "mouse_down":
                        held_buttons.add(event["button"])
                    elif event["kind"] == "mouse_up":
                        held_buttons.discard(event["button"])
                loop += 1
            msg = "Lecture arrêtée." if self.stop_event.is_set() else "Lecture terminée."
            self.root.after(0, lambda m=msg: self._play_finished(m))
        except Exception as exc:
            self.root.after(0, lambda e=str(exc): self._play_finished("Erreur de lecture : " + e))
        finally:
            # Empêche une touche ou un clic de rester coincé si F8 coupe une macro au milieu.
            for name in held_keys:
                try:
                    key = self._key_from_name(name)
                    if key is not None:
                        self.keyboard_controller.release(key)
                except Exception:
                    pass
            for name in held_buttons:
                try:
                    self.mouse_controller.release(getattr(Button, name, Button.left))
                except Exception:
                    pass

    def _perform(self, event):
        kind = event["kind"]
        if kind in ("key_down", "key_up"):
            key = self._key_from_name(event["key"])
            if key is None:
                return
            if kind == "key_down":
                self.keyboard_controller.press(key)
            else:
                self.keyboard_controller.release(key)
        elif kind == "mouse_move":
            self.mouse_controller.position = (event["x"], event["y"])
        elif kind == "mouse_move_delta":
            dx, dy = int(event.get("dx", 0)), int(event.get("dy", 0))
            # Mouvement relatif Windows : mieux adapté aux caméras de jeux qui verrouillent le curseur.
            # Il reste dépendant de la façon dont Roblox/le jeu accepte les entrées synthétiques.
            # Amplification modérée pour compenser le mouvement parfois trop faible dans Roblox.
            dx = max(-300, min(300, int(dx * 1.7)))
            dy = max(-300, min(300, int(dy * 1.7)))
            if os.name == "nt":
                class MOUSEINPUT(ctypes.Structure):
                    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                                ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                                ("time", ctypes.c_ulong), ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]
                class INPUT(ctypes.Structure):
                    _fields_ = [("type", ctypes.c_ulong), ("mi", MOUSEINPUT)]
                inp = INPUT(0, MOUSEINPUT(dx, dy, 0, 0x0001, 0, None))
                ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
            else:
                self.mouse_controller.move(dx, dy)
        elif kind in ("mouse_down", "mouse_up"):
            self.mouse_controller.position = (event["x"], event["y"])
            button = getattr(Button, event["button"], Button.left)
            if kind == "mouse_down":
                self.mouse_controller.press(button)
            else:
                self.mouse_controller.release(button)

    def _play_finished(self, message):
        self.playing = False
        self.play_btn.configure(state="normal")
        self.record_btn.configure(state="normal")
        self.status.set(message)

    def start_autoclick(self):
        if self.recording or self.playing or self.spam_running:
            messagebox.showwarning(APP_TITLE, "Arrête l'enregistrement, la macro ou l'autre outil avant.")
            return
        try:
            interval = float(self.click_interval_var.get())
            if interval < 0.02 or interval > 60:
                raise ValueError
        except ValueError:
            messagebox.showerror(APP_TITLE, "Intervalle d'auto-clic : entre 0,02 et 60 secondes.")
            return
        if not messagebox.askyesno(APP_TITLE, "Démarrer les clics gauches répétés ? F8 arrête tout."):
            return
        self._start_spammer("click", interval, None)

    def capture_spam_key(self):
        if self.recording or self.playing or self.spam_running:
            messagebox.showwarning(APP_TITLE, "Arrête d'abord l'enregistrement, la macro ou les répétitions.")
            return
        win = tk.Toplevel(self.root)
        win.title("Choisir une touche")
        win.transient(self.root)
        win.grab_set()
        win.geometry("330x120")
        ttk.Label(win, text="Appuie sur la touche à répéter…").pack(pady=(22, 10))
        ttk.Label(win, text="Espace, lettres, chiffres et touches spéciales sont acceptés.").pack()
        def on_press(key):
            name = self._key_name(key)
            # Les touches pynput spéciales sont stockées sous la forme Key.space, Key.enter, etc.
            display = "ESPACE" if name == "Key.space" else name
            self.root.after(0, lambda: self._set_captured_key(win, name, display))
            return False
        listener = keyboard.Listener(on_press=on_press)
        listener.start()

    def _set_captured_key(self, win, name, display):
        self.spam_key_var.set(name)
        try:
            win.grab_release()
            win.destroy()
        except tk.TclError:
            pass
        self.status.set(f"Touche choisie : {display}")

    def start_key_spam(self):
        if self.recording or self.playing or self.spam_running:
            messagebox.showwarning(APP_TITLE, "Arrête l'enregistrement, la macro ou l'autre outil avant.")
            return
        key_text = self.spam_key_var.get().strip()
        try:
            interval = float(self.spam_interval_var.get())
            if not key_text or (len(key_text) > 1 and not key_text.startswith("Key.")) or interval < 0.03 or interval > 60:
                raise ValueError
        except ValueError:
            messagebox.showerror(APP_TITLE, "Choisis une touche avec « Choisir une touche… » et un intervalle de 0,03 à 60 secondes.")
            return
        if not messagebox.askyesno(APP_TITLE, f"Répéter la touche « {key_text} » ? F8 arrête tout."):
            return
        self._start_spammer("key", interval, key_text)

    def _start_spammer(self, mode, interval, key_text):
        self.spam_stop_event.clear()
        self.spam_running = True
        self.status.set("Répétition active… F8 ou « Arrêter les répétitions » pour stopper.")
        threading.Thread(target=self._spam_worker, args=(mode, interval, key_text), daemon=True).start()

    def _spam_worker(self, mode, interval, key_text):
        try:
            while not self.spam_stop_event.is_set():
                if mode == "click":
                    self.mouse_controller.click(Button.left, 1)
                else:
                    self._send_spam_key(key_text)
                if self.spam_stop_event.wait(interval):
                    break
        finally:
            self.root.after(0, self._spam_finished)

    def _send_spam_key(self, key_text):
        key = self._key_from_name(key_text)
        if os.name == "nt":
            # Win32 SendInput emits a key-down and key-up pair, including Space and special keys.
            VK = {
                "Key.space": 0x20, "Key.enter": 0x0D, "Key.tab": 0x09,
                "Key.backspace": 0x08, "Key.delete": 0x2E, "Key.insert": 0x2D,
                "Key.esc": 0x1B, "Key.up": 0x26, "Key.down": 0x28,
                "Key.left": 0x25, "Key.right": 0x27, "Key.shift": 0x10,
                "Key.ctrl": 0x11, "Key.alt": 0x12,
            }
            if key_text in VK:
                vk = VK[key_text]
            elif key_text.upper().startswith("F") and key_text[1:].isdigit():
                n = int(key_text[1:])
                vk = 0x70 + n - 1 if 1 <= n <= 12 else None
            elif len(key_text) == 1:
                vk = ord(key_text.upper())
            else:
                vk = None
            if vk is not None:
                class KBI(ctypes.Structure):
                    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                                ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]
                class INPUT(ctypes.Structure):
                    _fields_ = [("type", ctypes.c_ulong), ("ki", KBI)]
                for flags in (0, 0x0002):
                    inp = INPUT(1, KBI(vk, 0, flags, 0, None))
                    ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
                return
        self.keyboard_controller.press(key)
        self.keyboard_controller.release(key)

    def stop_spam_tools(self):
        self.spam_stop_event.set()

    def stop_all(self):
        self.stop_event.set()
        self.spam_stop_event.set()
        if self.recording:
            self.stop_recording()
        self.status.set("Arrêt demandé. F8 arrête la lecture et les répétitions.")

    def _spam_finished(self):
        self.spam_running = False
        self.status.set("Répétitions arrêtées.")

    def _refresh_list(self):
        self.listbox.delete(0, "end")
        for i, e in enumerate(self.events):
            delay = e.get("delay", 0)
            if e["kind"].startswith("key"):
                desc = f"{e['kind']:10} {e['key']}"
            elif e["kind"] == "mouse_move":
                desc = f"mouse_move  vers ({e['x']}, {e['y']})"
            elif e["kind"] == "mouse_move_delta":
                desc = f"mouvement relatif dx={e.get('dx', 0)}, dy={e.get('dy', 0)}"
            else:
                desc = f"{e['kind']:10} {e['button']} à ({e['x']}, {e['y']})"
            self.listbox.insert("end", f"{i+1:04d}  +{delay:5.2f}s  {desc}")

    def delete_selected(self):
        selected = list(self.listbox.curselection())
        if not selected:
            return
        for index in reversed(selected):
            del self.events[index]
        self._refresh_list()
        self.status.set(f"{len(selected)} action(s) supprimée(s).")

    def clear_events(self):
        if self.recording or self.playing:
            messagebox.showwarning(APP_TITLE, "Arrête l'enregistrement ou la lecture d'abord.")
            return
        if self.events and not messagebox.askyesno(APP_TITLE, "Effacer toutes les actions de la macro ? Cette action ne peut pas être annulée."):
            return
        self.events = []
        self._refresh_list()
        self.status.set("Macro effacée.")

    def save_macro(self):
        if not self.events:
            messagebox.showinfo(APP_TITLE, "Il n'y a aucune action à enregistrer.")
            return
        path = filedialog.asksaveasfilename(title="Enregistrer la macro", defaultextension=".json",
                                            filetypes=[("Macro Roblox Macro Studio", "*.json"), ("Tous les fichiers", "*.*")])
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"format": "RobloxMacroStudio", "version": VERSION, "events": self.events},
                          f, ensure_ascii=False, indent=2)
            self.status.set("Macro enregistrée : " + path)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Impossible d'enregistrer : {exc}")

    def load_macro(self):
        if self.recording or self.playing or self.spam_running:
            messagebox.showwarning(APP_TITLE, "Arrête les actions actives d'abord.")
            return
        path = filedialog.askopenfilename(title="Ouvrir une macro",
                                          filetypes=[("Macro Roblox Macro Studio", "*.json"), ("Tous les fichiers", "*.*")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            events = data.get("events")
            if not isinstance(events, list):
                raise ValueError("Ce fichier ne contient pas une liste d'actions valide.")
            valid = []
            for e in events:
                if not isinstance(e, dict):
                    continue
                if e.get("kind") in ("key_down", "key_up") and isinstance(e.get("key"), str):
                    valid.append(e)
                elif e.get("kind") == "mouse_move" and all(k in e for k in ("x", "y")):
                    valid.append(e)
                elif e.get("kind") in ("mouse_down", "mouse_up") and all(k in e for k in ("x", "y", "button")):
                    if e["button"] in ("left", "right", "middle"):
                        valid.append(e)
            self.events = valid
            self._refresh_list()
            self.status.set(f"Macro chargée : {len(self.events)} actions.")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Impossible de lire cette macro : {exc}")

    def close(self):
        self.stop_event.set()
        self.spam_stop_event.set()
        self.recording = False
        for listener in (self.keyboard_listener, self.mouse_listener, self.hotkey_listener):
            if listener:
                try:
                    listener.stop()
                except Exception:
                    pass
        self.root.destroy()

def main():
    root = tk.Tk()
    MacroStudio(root)
    root.mainloop()

if __name__ == "__main__":
    main()
